//
//  ViewController.swift
//  Test_1_2
//
//  Created by Ravneet Kaur on 2019-04-06.
//  Copyright © 2019 Ravneet Kaur. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

