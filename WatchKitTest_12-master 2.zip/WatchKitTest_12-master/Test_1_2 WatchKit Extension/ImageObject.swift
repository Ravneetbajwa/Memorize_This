//
//  ImageObject.swift
//  Test_1_2 WatchKit Extension
//
//  Created by Ravneet Kaur on 2019-04-06.
//  Copyright © 2019 Ravneet Kaur. All rights reserved.
//

import WatchKit

class ImageObject: NSObject {
    // MARK:
    //var name: String?
    var image: String?
    
    override convenience init(){
        self.init(image:"image_1")
    }
    
    init(image:String){
        self.image = image
        //self.name = name
    }
    

}
